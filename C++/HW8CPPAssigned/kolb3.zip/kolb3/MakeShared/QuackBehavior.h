#ifndef QUACKBEHAVIOR_H_
#define QUACKBEHAVIOR_H_

class QuackBehavior {
public:
   virtual void quack( ) = 0;
};
#endif /* QUACKBEHAVIOR_H_ */
